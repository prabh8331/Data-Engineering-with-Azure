Introduction to linux - https://www.youtube.com/watch?v=sWbUDq4S6Y8

Linux Commands - https://www.youtube.com/watch?v=YHFzr-akOas&list=PLS1QulWo1RIb9WVQGJ_vh-RQusbZgO_As

How to get Linux on Windows - https://www.youtube.com/watch?v=eAoLQwGpWJs

50 Most used Linux Commands - https://www.javatpoint.com/linux-commands
