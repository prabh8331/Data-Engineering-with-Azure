Reading Material

-> Python Complete - https://youtu.be/_uQrJ0TkZlc

-> Pandas Complete - https://www.youtube.com/watch?v=vmEHCJofslg

--------------------------------------------------------------------

Python DSA Question Practise

-> DSA Question (Check Only Python Solutions) - https://medium.com/techie-delight/500-data-structures-and-algorithms-practice-problems-35afe8a1e222

--------------------------------------------------------------------

How to install Python

-> Install Python (Windows, Mac, Linux) - https://realpython.com/installing-python/

--------------------------------------------------------------------

How to install Jupyter Notebook (Optional to install but good for practising Python)

-> Install Jupyter Notebook - https://mljar.com/blog/install-jupyter-notebook/

--------------------------------------------------------------------

Install PyCharm Community Version in your respective system

-> PyCharm IDE Setup - https://www.jetbrains.com/pycharm/download/#section=windows

--------------------------------------------------------------------

Install Visual Studio Code in your respective system

-> Visual Studio Code IDE Setup - https://code.visualstudio.com/download
