list = [1,2,46,4652,"abhaya","rohan"]

for index,item in enumerate(list):
    print(index,":",item)