num = int(input("Enter the number :"))
f = 1
i = 1
for i in range(i, num+1):
    f *= i

print (f)