import webbrowser
#Assigning URL to be opened
strURL = "http://www.csestack.org"
#Open url in default browser
webbrowser.open(strURL, new=2)