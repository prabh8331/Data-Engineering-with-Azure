import time
print("Printed immediately.")
time.sleep(2.4)
print("Printed after 2.4 seconds.")