# Set union method

A = {1, 2, 3, 4, 5}
B = {4, 5, 6, 7, 8}
print(A | B)

# Intersection of sets

A = {1, 2, 3, 4, 5}
B = {4, 5, 6, 7, 8}
print(A & B)

# Difference of two sets

A = {1, 2, 3, 4, 5}
B = {4, 5, 6, 7, 8}
print(A - B)