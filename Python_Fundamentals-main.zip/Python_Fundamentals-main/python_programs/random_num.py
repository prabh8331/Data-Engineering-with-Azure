#Program to generate Random by the system
import random 
randomNo = random.randint(1,5)
print(randomNo)